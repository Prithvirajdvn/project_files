import os
import xml.etree.ElementTree as ET

# Define paths
xml_folder = r'C:\Users\NANI\Desktop\t3\final_data\train\xmls'  # Update the folder name to 'xmls'
txt_folder = r'C:\Users\NANI\Desktop\t3\final_data\train\labels'  # Separate folder for .txt files
classes = ['Hello', 'I Love You', 'No', 'Thanks', 'Yes']  # Modify according to your classes

# Make sure output folder exists
os.makedirs(txt_folder, exist_ok=True)

# Convert each XML file
for xml_file in os.listdir(xml_folder):
    if xml_file.endswith('.xml'):
        # Parse XML
        tree = ET.parse(os.path.join(xml_folder, xml_file))
        root = tree.getroot()
        img_width = int(root.find('size/width').text)
        img_height = int(root.find('size/height').text)

        # Create corresponding .txt file
        txt_file_path = os.path.join(txt_folder, xml_file.replace('.xml', '.txt'))
        with open(txt_file_path, 'w') as txt_file:
            for obj in root.findall('object'):
                class_name = obj.find('name').text
                if class_name in classes:
                    class_id = classes.index(class_name)
                    bbox = obj.find('bndbox')
                    xmin = int(bbox.find('xmin').text)
                    xmax = int(bbox.find('xmax').text)
                    ymin = int(bbox.find('ymin').text)
                    ymax = int(bbox.find('ymax').text)

                    # Convert to YOLO format
                    x_center = (xmin + xmax) / 2 / img_width
                    y_center = (ymin + ymax) / 2 / img_height
                    width = (xmax - xmin) / img_width
                    height = (ymax - ymin) / img_height

                    txt_file.write(f"{class_id} {x_center} {y_center} {width} {height}\n")